export const C = {
  bgMain: '#0a0d12',
  bgCard: '#0f1318',
  bgInput: '#151a22',
  bgHover: '#1c2330',
  gold: '#c8a84b',
  goldBright: '#e8c96a',
  success: '#2dd4a0',
  danger: '#e25555',
  info: '#5b9cf6',
  textPrimary: '#e8e4dc',
  textSec: '#8a8a8a',
  textMuted: '#555555',
  border: 'rgba(255,255,255,0.07)',
  borderMed: 'rgba(255,255,255,0.12)',
  borderGold: 'rgba(200,168,75,0.3)',
} as const;

export const FONTS = {
  arabic: "'IBM Plex Sans Arabic', sans-serif",
  mono: "'IBM Plex Mono', monospace",
  display: "'Playfair Display', serif",
} as const;

