import React, { useState, useEffect } from 'react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer
} from 'recharts';
import { C, FONTS } from './colors';

const generateChartData = () =>
  Array.from({ length: 30 }, (_, i) => ({
    day: `${i + 1}`,
    value: Math.floor(Math.random() * 14) + 2,
  }));

const chartData = generateChartData();

const statuses = [
  { label: 'ناجحة', bg: 'rgba(45,212,160,0.12)', color: C.success },
  { label: 'ناجحة', bg: 'rgba(45,212,160,0.12)', color: C.success },
  { label: 'جارٍ', bg: 'rgba(200,168,75,0.12)', color: C.gold, pulse: true },
];

const recentOps = [
  { product: 'سجاد تركي', flag: '🇫🇷', country: 'فرنسا', importers: 10, messages: 10, time: 'منذ ساعتين', status: 'ناجحة' },
  { product: 'خلاط حمص', flag: '🇩🇪', country: 'ألمانيا', importers: 15, messages: 15, time: 'أمس', status: 'ناجحة' },
  { product: 'منتجات بلاستيك', flag: '🇳🇱', country: 'هولندا', importers: 0, messages: 0, time: 'قيد التنفيذ', status: 'جارٍ' },
  { product: 'زيت أرغان', flag: '🇬🇧', country: 'بريطانيا', importers: 8, messages: 8, time: 'منذ 3 أيام', status: 'ناجحة' },
  { product: 'توابل مغربية', flag: '🇮🇹', country: 'إيطاليا', importers: 0, messages: 0, time: 'منذ ساعة', status: 'فشل' },
];

interface StatCard {
  title: string;
  value: string;
  indicator: string;
  indicatorColor: string;
  icon: string;
  topColor?: string;
}

const stats: StatCard[] = [
  { title: 'إجمالي المستوردين', value: '127', indicator: '▲ +23 هذا الأسبوع', indicatorColor: C.success, icon: '👥', topColor: C.gold },
  { title: 'الرسائل الجاهزة', value: '98', indicator: '✓ بـ 4 لغات', indicatorColor: C.success, icon: '✉️', topColor: C.gold },
  { title: 'عمليات البحث', value: '12', indicator: 'آخر بحث: منذ ساعتين', indicatorColor: C.textMuted, icon: '🔍', topColor: C.gold },
  { title: 'التوفير (BYOK)', value: '$320', indicator: 'موفّر هذا الشهر', indicatorColor: C.textMuted, icon: '💰', topColor: C.success },
];

function useCounter(target: number, duration = 700) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    let start = 0;
    const step = Math.ceil(target / (duration / 16));
    const timer = setInterval(() => {
      start += step;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(start);
      }
    }, 16);
    return () => clearInterval(timer);
  }, [target, duration]);
  return count;
}

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: '#0f1318',
      border: `1px solid ${C.gold}`,
      borderRadius: 8,
      padding: '8px 12px',
      fontSize: 12,
      fontFamily: FONTS.arabic,
    }}>
      <div style={{ color: C.textMuted, marginBottom: 2 }}>يوم {label}</div>
      <div style={{ color: C.gold, fontFamily: FONTS.mono }}>{payload[0].value} مستورد</div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { bg: string; color: string; pulse?: boolean }> = {
    'ناجحة': { bg: 'rgba(45,212,160,0.12)', color: C.success },
    'جارٍ': { bg: 'rgba(200,168,75,0.12)', color: C.gold, pulse: true },
    'فشل': { bg: 'rgba(226,85,85,0.12)', color: C.danger },
  };
  const s = map[status] ?? map['ناجحة'];
  return (
    <span style={{
      background: s.bg,
      color: s.color,
      fontSize: 11,
      padding: '3px 8px',
      borderRadius: 20,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      fontFamily: FONTS.arabic,
      animation: s.pulse ? 'statusPulse 2s infinite' : undefined,
    }}>
      <span style={{ width: 5, height: 5, background: s.color, borderRadius: '50%', display: 'inline-block' }} />
      {status}
    </span>
  );
}

export function Dashboard() {
  return (
    <div style={{ fontFamily: FONTS.arabic, direction: 'rtl' }}>
      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <h1 style={{
          fontFamily: FONTS.display,
          fontSize: 28,
          fontWeight: 700,
          color: C.textPrimary,
          margin: 0,
          lineHeight: 1.3,
        }}>لوحة التحكم العامة</h1>
        <p style={{ fontSize: 14, color: C.textSec, marginTop: 6, margin: '6px 0 0' }}>
          ملخص فوري لعمليات البحث والمستوردين والرسائل
        </p>
      </div>

      {/* Stat Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 16, marginBottom: 24 }}>
        {stats.map((s, i) => (
          <StatCard key={i} stat={s} delay={i * 80} />
        ))}
      </div>

      {/* Chart */}
      <div style={{
        background: C.bgCard,
        border: `1px solid ${C.border}`,
        borderTop: `2px solid ${C.gold}`,
        borderRadius: 16,
        padding: 24,
        marginBottom: 24,
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', top: 0, right: 0, width: 200, height: 200,
          background: 'radial-gradient(circle, rgba(200,168,75,0.06) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 15, color: C.textPrimary, fontWeight: 600 }}>
            معدل اكتشاف المستوردين — آخر 30 يوماً
          </div>
          <div style={{ fontSize: 12, color: C.textSec, marginTop: 4 }}>
            عدد المستوردين المكتشفين يومياً
          </div>
        </div>
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={chartData} margin={{ top: 8, right: 0, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="goldGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={C.gold} stopOpacity={0.18} />
                <stop offset="100%" stopColor={C.gold} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e2530" vertical={false} />
            <XAxis
              dataKey="day"
              tick={{ fill: C.textMuted, fontSize: 10, fontFamily: FONTS.mono }}
              axisLine={false}
              tickLine={false}
              interval={4}
            />
            <YAxis
              tick={{ fill: C.textMuted, fontSize: 10, fontFamily: FONTS.mono }}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area
              type="monotone"
              dataKey="value"
              stroke={C.gold}
              strokeWidth={2}
              fill="url(#goldGrad)"
              dot={false}
              activeDot={{ r: 5, fill: C.goldBright, strokeWidth: 0 }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Recent Operations Table */}
      <div style={{
        background: C.bgCard,
        border: `1px solid ${C.border}`,
        borderRadius: 16,
        overflow: 'hidden',
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '16px 20px',
          borderBottom: `1px solid ${C.border}`,
        }}>
          <div style={{ fontSize: 15, color: C.textPrimary, fontWeight: 600 }}>عمليات البحث الأخيرة</div>
          <button style={{
            background: 'none',
            border: 'none',
            color: C.gold,
            fontSize: 13,
            cursor: 'pointer',
            fontFamily: FONTS.arabic,
          }}>عرض الكل ←</button>
        </div>

        {/* Table Header */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: '2fr 1.2fr 80px 80px 1.2fr 100px',
          padding: '10px 20px',
          background: 'rgba(255,255,255,0.02)',
          borderBottom: `1px solid ${C.border}`,
        }}>
          {['المنتج', 'الدولة', 'المستوردون', 'الرسائل', 'التوقيت', 'الحالة'].map((h) => (
            <div key={h} style={{
              fontSize: 11,
              color: C.textMuted,
              textTransform: 'uppercase',
              letterSpacing: '0.08em',
              fontFamily: FONTS.arabic,
            }}>{h}</div>
          ))}
        </div>

        {recentOps.map((op, i) => (
          <div
            key={i}
            style={{
              display: 'grid',
              gridTemplateColumns: '2fr 1.2fr 80px 80px 1.2fr 100px',
              padding: '14px 20px',
              borderBottom: i < recentOps.length - 1 ? `1px solid rgba(255,255,255,0.05)` : 'none',
              background: i % 2 === 1 ? 'rgba(255,255,255,0.01)' : 'transparent',
              transition: 'background 0.15s',
            }}
            onMouseEnter={(e) => (e.currentTarget.style.background = 'rgba(255,255,255,0.02)')}
            onMouseLeave={(e) => (e.currentTarget.style.background = i % 2 === 1 ? 'rgba(255,255,255,0.01)' : 'transparent')}
          >
            <div style={{ fontSize: 13, color: C.textPrimary }}>{op.product}</div>
            <div style={{ fontSize: 13, color: C.textSec }}>
              {op.flag} {op.country}
            </div>
            <div style={{ fontSize: 13, color: C.textPrimary, fontFamily: FONTS.mono }}>
              {op.importers || '—'}
            </div>
            <div style={{ fontSize: 13, color: C.textPrimary, fontFamily: FONTS.mono }}>
              {op.messages || '—'}
            </div>
            <div style={{ fontSize: 12, color: C.textSec }}>{op.time}</div>
            <div><StatusBadge status={op.status} /></div>
          </div>
        ))}
      </div>

      <style>{`
        @keyframes statusPulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.6; }
        }
      `}</style>
    </div>
  );
}

function StatCard({ stat, delay }: { stat: StatCard; delay: number }) {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setVisible(true), delay);
    return () => clearTimeout(t);
  }, [delay]);

  return (
    <div style={{
      background: C.bgCard,
      border: `1px solid ${C.border}`,
      borderTop: `2px solid ${stat.topColor}`,
      borderRadius: 16,
      padding: '20px',
      position: 'relative',
      overflow: 'hidden',
      opacity: visible ? 1 : 0,
      transform: visible ? 'translateY(0)' : 'translateY(12px)',
      transition: 'opacity 0.4s ease, transform 0.4s ease',
    }}>
      <div style={{
        position: 'absolute', top: 0, right: 0, width: 100, height: 100,
        background: 'radial-gradient(circle, rgba(200,168,75,0.07) 0%, transparent 70%)',
        pointerEvents: 'none',
      }} />
      <div style={{ fontSize: 11, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>
        {stat.title}
      </div>
      <div style={{
        fontSize: '2rem',
        fontFamily: FONTS.mono,
        color: stat.topColor === C.success ? C.success : C.textPrimary,
        fontWeight: 500,
        lineHeight: 1.2,
        marginBottom: 6,
      }}>
        {stat.value}
      </div>
      <div style={{ fontSize: 11, color: stat.indicatorColor }}>{stat.indicator}</div>
      <div style={{
        position: 'absolute',
        bottom: 16,
        left: 16,
        fontSize: 20,
        opacity: 0.25,
      }}>{stat.icon}</div>
    </div>
  );
}
