import React, { useState } from 'react';
import { C, FONTS } from './colors';

interface Competitor {
  flag: string;
  name: string;
  country: string;
  metrics: { label: string; value: string }[];
  weakness: string;
}

const competitors: Competitor[] = [
  {
    flag: '🇨🇳', name: 'Shanghai Textile Co.', country: 'الصين',
    metrics: [
      { label: 'حجم التصدير', value: '$2.4M/سنة' },
      { label: 'الأسواق', value: 'أوروبا، آسيا' },
      { label: 'عدد المنتجات', value: '340 SKU' },
      { label: 'وقت التسليم', value: '45-60 يوم' },
      { label: 'السعر', value: '$12-18/متر' },
    ],
    weakness: '⚡ وقت شحن طويل — ميزتك: التسليم الأسرع',
  },
  {
    flag: '🇮🇳', name: 'Mumbai Exports Ltd', country: 'الهند',
    metrics: [
      { label: 'حجم التصدير', value: '$1.8M/سنة' },
      { label: 'الأسواق', value: 'بريطانيا، فرنسا' },
      { label: 'عدد المنتجات', value: '210 SKU' },
      { label: 'وقت التسليم', value: '35-50 يوم' },
      { label: 'السعر', value: '$9-14/متر' },
    ],
    weakness: '⚡ جودة متوسطة — ميزتك: الجودة اليدوية الأعلى',
  },
  {
    flag: '🇹🇷', name: 'Istanbul Trade Corp', country: 'تركيا',
    metrics: [
      { label: 'حجم التصدير', value: '$3.1M/سنة' },
      { label: 'الأسواق', value: 'ألمانيا، هولندا' },
      { label: 'عدد المنتجات', value: '520 SKU' },
      { label: 'وقت التسليم', value: '20-30 يوم' },
      { label: 'السعر', value: '$18-28/متر' },
    ],
    weakness: '⚡ أسعار مرتفعة — ميزتك: سعر أقل بجودة مماثلة',
  },
  {
    flag: '🇵🇰', name: 'Karachi Wholesale', country: 'باكستان',
    metrics: [
      { label: 'حجم التصدير', value: '$900K/سنة' },
      { label: 'الأسواق', value: 'إيطاليا، إسبانيا' },
      { label: 'عدد المنتجات', value: '150 SKU' },
      { label: 'وقت التسليم', value: '40-55 يوم' },
      { label: 'السعر', value: '$7-11/متر' },
    ],
    weakness: '⚡ تنوع محدود — ميزتك: مجموعة أوسع وتخصيص أكثر',
  },
  {
    flag: '🇻🇳', name: 'Hanoi Fabric Group', country: 'فيتنام',
    metrics: [
      { label: 'حجم التصدير', value: '$1.2M/سنة' },
      { label: 'الأسواق', value: 'فرنسا، بلجيكا' },
      { label: 'عدد المنتجات', value: '180 SKU' },
      { label: 'وقت التسليم', value: '40-60 يوم' },
      { label: 'السعر', value: '$8-13/متر' },
    ],
    weakness: '⚡ ضعف التسويق الرقمي — ميزتك: حضور رقمي أقوى',
  },
  {
    flag: '🇮🇩', name: 'Jakarta Export House', country: 'إندونيسيا',
    metrics: [
      { label: 'حجم التصدير', value: '$750K/سنة' },
      { label: 'الأسواق', value: 'هولندا، بلجيكا' },
      { label: 'عدد المنتجات', value: '120 SKU' },
      { label: 'وقت التسليم', value: '50-65 يوم' },
      { label: 'السعر', value: '$6-10/متر' },
    ],
    weakness: '⚡ تغطية جغرافية محدودة — ميزتك: شبكة توزيع أوسع',
  },
];

export function Competitors() {
  const [hovered, setHovered] = useState<string | null>(null);

  return (
    <div style={{ fontFamily: FONTS.arabic, direction: 'rtl' }}>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 22, fontWeight: 600, color: C.textPrimary, margin: '0 0 6px' }}>
          تحليل المنافسين
        </h1>
        <p style={{ fontSize: 13, color: C.textSec, margin: 0 }}>
          أبرز المنافسين الصينيين والآسيويين في أسواقك المستهدفة
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
        {competitors.map((c) => {
          const isHovered = hovered === c.name;
          return (
            <div
              key={c.name}
              onMouseEnter={() => setHovered(c.name)}
              onMouseLeave={() => setHovered(null)}
              style={{
                background: C.bgCard,
                border: `1px solid ${isHovered ? C.borderMed : C.border}`,
                borderRadius: 12,
                padding: 20,
                transition: 'all 0.2s ease',
                transform: isHovered ? 'translateY(-2px)' : 'translateY(0)',
              }}
            >
              {/* Header */}
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10, marginBottom: 14 }}>
                <span style={{ fontSize: 24 }}>{c.flag}</span>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 500, color: C.textPrimary }}>{c.name}</div>
                  <div style={{ fontSize: 11, color: C.textMuted, marginTop: 2 }}>{c.country}</div>
                </div>
              </div>

              {/* Metrics */}
              <div style={{ marginBottom: 14 }}>
                {c.metrics.map((m) => (
                  <div key={m.label} style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '5px 0',
                    borderBottom: `1px solid rgba(255,255,255,0.04)`,
                  }}>
                    <span style={{ fontSize: 11, color: C.textMuted }}>{m.label}</span>
                    <span style={{ fontSize: 11, color: C.textPrimary, fontFamily: FONTS.mono }}>{m.value}</span>
                  </div>
                ))}
              </div>

              {/* Weakness */}
              <div style={{
                borderTop: `1px solid ${C.border}`,
                paddingTop: 12,
                fontSize: 11,
                color: C.gold,
                lineHeight: 1.5,
              }}>{c.weakness}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
