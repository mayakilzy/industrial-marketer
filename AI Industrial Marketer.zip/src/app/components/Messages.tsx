import React, { useState } from 'react';
import { toast } from 'sonner';
import { C, FONTS } from './colors';

interface Message {
  id: number;
  company: string;
  preview: string;
  lang: 'DE' | 'FR' | 'EN' | 'AR' | 'IT' | 'ES';
  subject: string;
  recipient: string;
  body: string;
}

const langColors: Record<string, { bg: string; color: string }> = {
  DE: { bg: 'rgba(226,85,85,0.15)', color: '#e25555' },
  FR: { bg: 'rgba(91,156,246,0.15)', color: C.info },
  EN: { bg: 'rgba(45,212,160,0.15)', color: C.success },
  AR: { bg: 'rgba(200,168,75,0.15)', color: C.gold },
  IT: { bg: 'rgba(168,85,247,0.15)', color: '#a855f7' },
  ES: { bg: 'rgba(251,146,60,0.15)', color: '#fb923c' },
};

const messages: Message[] = [
  {
    id: 1, company: 'Euro Trade GmbH', lang: 'DE',
    preview: 'Sehr geehrter Herr Mueller, wir freuen uns...',
    subject: 'Premium Türkische Teppiche — Partnerschaftsanfrage',
    recipient: 'Hans Mueller — Euro Trade GmbH',
    body: `Sehr geehrter Herr Mueller,

wir freuen uns, Ihnen unsere hochwertigen türkischen Teppiche vorstellen zu dürfen. Unser Unternehmen ist seit über 20 Jahren in der Herstellung und dem Export von handgefertigten Teppichen tätig.

Unsere Produkte zeichnen sich durch:
• Hochwertige Materialien (100% Wolle und Seide)
• Traditionelle Handarbeit
• Wettbewerbsfähige Preise
• Schnelle Lieferzeiten (2-3 Wochen)

Wir würden uns freuen, Ihnen unser vollständiges Produktkatalog zuzusenden und die Möglichkeit einer Zusammenarbeit zu besprechen.

Mit freundlichen Grüßen,
Ahmad Al-Rashidi
Export Manager`,
  },
  {
    id: 2, company: 'Paris Import SARL', lang: 'FR',
    preview: 'Chère Claire, nous souhaitons vous présenter...',
    subject: 'Huile d\'Argan Premium — Proposition de partenariat',
    recipient: 'Claire Dupont — Paris Import SARL',
    body: `Chère Claire Dupont,

Nous sommes ravis de vous présenter notre gamme d'huile d'argan premium du Maroc. Notre société travaille directement avec des coopératives locales pour vous offrir un produit authentique et de haute qualité.

Nos avantages compétitifs:
• Certification biologique européenne
• Production durable et éthique
• Prix à partir de €8/100ml
• Livraison sous 10-14 jours

Nous serions heureux de vous envoyer des échantillons gratuits pour votre évaluation.

Cordialement,
Ahmad Al-Rashidi
Directeur Export`,
  },
  {
    id: 3, company: 'Amsterdam Goods BV', lang: 'EN',
    preview: 'Dear Jan, we would like to introduce our premium...',
    subject: 'Moroccan Spices Collection — Partnership Opportunity',
    recipient: 'Jan de Vries — Amsterdam Goods BV',
    body: `Dear Jan de Vries,

I hope this message finds you well. We are reaching out to introduce our premium collection of authentic Moroccan spices and herbs.

Our product range includes:
• Ras el Hanout (signature blend)
• Cumin, Turmeric, Paprika (certified organic)
• Traditional Harissa paste
• Saffron (Grade 1)

All products come with EU food safety certification and can be customized with your private label. We offer competitive wholesale pricing starting from €2.50/kg.

We look forward to exploring a potential partnership.

Best regards,
Ahmad Al-Rashidi
Export Sales Manager`,
  },
  {
    id: 4, company: 'Mediterranean Corp', lang: 'IT',
    preview: 'Cara Sofia, vorremmo presentarvi i nostri...',
    subject: 'Prodotti Alimentari Artigianali — Proposta di Collaborazione',
    recipient: 'Sofia Rossi — Mediterranean Corp',
    body: `Cara Sofia Rossi,

Siamo lieti di presentarle la nostra selezione di prodotti alimentari artigianali nordafricani. La nostra azienda è specializzata nell'esportazione di prodotti tradizionali di alta qualità verso il mercato europeo.

La nostra offerta include:
• Olio d'argan biologico
• Spezie e aromi tradizionali
• Couscous artigianale
• Prodotti a base di datteri

Tutti i prodotti sono certificati per il mercato europeo. Siamo disponibili a organizzare una video call per presentare il nostro catalogo completo.

Cordiali saluti,
Ahmad Al-Rashidi`,
  },
  {
    id: 5, company: 'Nordic Supply AB', lang: 'EN',
    preview: 'Dear Erik, we are pleased to introduce our textile...',
    subject: 'Premium Textile Products — Export Partnership',
    recipient: 'Erik Larsson — Nordic Supply AB',
    body: `Dear Erik Larsson,

We are pleased to reach out and introduce our premium textile products from Morocco. Our company specializes in high-quality handwoven textiles with both traditional and contemporary designs.

Our textile collection features:
• Handwoven Berber blankets
• Kilim rugs (custom sizes available)
• Cotton and wool blends
• Sustainable production methods

We maintain strict quality control and can provide samples upon request. Our pricing is competitive with fast turnaround times.

Kind regards,
Ahmad Al-Rashidi
Export Manager`,
  },
];

export function Messages() {
  const [selected, setSelected] = useState<Message>(messages[0]);

  return (
    <div style={{ fontFamily: FONTS.arabic, direction: 'rtl', display: 'flex', gap: 0, height: 'calc(100vh - 140px)' }}>
      {/* Sidebar list */}
      <div style={{
        width: 260,
        flexShrink: 0,
        borderLeft: `1px solid ${C.border}`,
        overflowY: 'auto',
        background: C.bgCard,
        borderRadius: '0 16px 16px 0',
      }}>
        <div style={{
          padding: '14px 16px',
          borderBottom: `1px solid ${C.border}`,
          fontSize: 15,
          fontWeight: 600,
          color: C.textPrimary,
        }}>
          الرسائل
          <span style={{
            marginRight: 8,
            background: 'rgba(45,212,160,0.15)',
            color: C.success,
            fontSize: 11,
            padding: '2px 8px',
            borderRadius: 10,
            fontFamily: FONTS.mono,
          }}>{messages.length}</span>
        </div>

        {messages.map((msg) => {
          const isActive = selected.id === msg.id;
          const lc = langColors[msg.lang];
          return (
            <div
              key={msg.id}
              onClick={() => setSelected(msg)}
              style={{
                padding: '12px 16px',
                borderBottom: `1px solid rgba(255,255,255,0.04)`,
                cursor: 'pointer',
                background: isActive ? C.bgHover : 'transparent',
                borderRight: isActive ? `3px solid ${C.gold}` : '3px solid transparent',
                transition: 'all 0.15s',
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 4 }}>
                <div style={{ fontSize: 13, color: isActive ? C.textPrimary : '#ccc', fontWeight: isActive ? 600 : 400 }}>
                  {msg.company}
                </div>
                <span style={{
                  background: lc.bg,
                  color: lc.color,
                  fontSize: 9,
                  padding: '2px 5px',
                  borderRadius: 4,
                  fontFamily: FONTS.mono,
                  flexShrink: 0,
                }}>{msg.lang}</span>
              </div>
              <div style={{
                fontSize: 11,
                color: C.textMuted,
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
                direction: 'ltr',
                textAlign: 'right',
              }}>{msg.preview}</div>
            </div>
          );
        })}
      </div>

      {/* Content area */}
      <div style={{
        flex: 1,
        background: C.bgCard,
        borderRadius: '16px 0 0 16px',
        padding: 28,
        overflowY: 'auto',
        border: `1px solid ${C.border}`,
        borderRight: 'none',
      }}>
        {/* Lang badge */}
        <div style={{ marginBottom: 16 }}>
          <span style={{
            background: langColors[selected.lang].bg,
            color: langColors[selected.lang].color,
            fontSize: 11,
            padding: '3px 10px',
            borderRadius: 20,
            fontFamily: FONTS.mono,
          }}>{selected.lang}</span>
        </div>

        {/* Subject */}
        <div style={{ marginBottom: 10 }}>
          <span style={{ fontSize: 12, color: C.textMuted }}>الموضوع: </span>
          <span style={{ fontSize: 14, color: C.textPrimary, fontWeight: 500 }}>{selected.subject}</span>
        </div>

        {/* Recipient */}
        <div style={{ marginBottom: 16 }}>
          <span style={{ fontSize: 12, color: C.textMuted }}>إلى: </span>
          <span style={{ fontSize: 13, color: C.gold }}>{selected.recipient}</span>
        </div>

        <div style={{ height: 1, background: `linear-gradient(90deg, ${C.gold}, transparent)`, marginBottom: 20 }} />

        {/* Message body */}
        <pre style={{
          fontFamily: FONTS.arabic,
          fontSize: 14,
          color: C.textPrimary,
          lineHeight: 1.75,
          whiteSpace: 'pre-wrap',
          direction: 'ltr',
          textAlign: 'left',
          margin: 0,
          marginBottom: 24,
        }}>{selected.body}</pre>

        {/* Actions */}
        <div style={{ display: 'flex', gap: 10 }}>
          <button
            onClick={() => {
              navigator.clipboard.writeText(selected.body);
              toast.success('تم نسخ الرسالة');
            }}
            style={{
              padding: '9px 20px',
              background: 'rgba(200,168,75,0.1)',
              border: `1px solid ${C.gold}`,
              color: C.gold,
              borderRadius: 8,
              fontSize: 13,
              cursor: 'pointer',
              fontFamily: FONTS.arabic,
            }}
          >نسخ الرسالة</button>
          <button
            onClick={() => toast.info('خاصية الإرسال تتطلب إعداد SMTP في الإعدادات')}
            style={{
              padding: '9px 20px',
              background: 'rgba(255,255,255,0.04)',
              border: `1px solid ${C.border}`,
              color: C.textSec,
              borderRadius: 8,
              fontSize: 13,
              cursor: 'pointer',
              fontFamily: FONTS.arabic,
            }}
          >إرسال *</button>
        </div>
      </div>
    </div>
  );
}
