import React, { useState, useEffect, useRef } from 'react';
import { toast } from 'sonner';
import { C, FONTS } from './colors';

const STEPS = [
  { id: 1, label: 'إرسال الطلب إلى Hermes AI...' },
  { id: 2, label: 'مسح المصادر الدولية للمستوردين...' },
  { id: 3, label: 'تحليل المنافسين الصينيين والآسيويين...' },
  { id: 4, label: 'توليد رسائل التواصل باللغة المختارة...' },
  { id: 5, label: 'حفظ البيانات في قاعدة البيانات...' },
];

type StepStatus = 'idle' | 'running' | 'done';

const languages = ['العربية', 'الفرنسية', 'الألمانية', 'الإنجليزية', 'الإيطالية', 'الإسبانية'];
const countries = ['فرنسا 🇫🇷', 'ألمانيا 🇩🇪', 'هولندا 🇳🇱', 'إيطاليا 🇮🇹', 'إسبانيا 🇪🇸', 'بريطانيا 🇬🇧'];

interface ResultRow {
  company: string;
  contact: string;
  email: string;
  country: string;
  score: number;
  ready: boolean;
}

function AnimatedCounter({ target }: { target: number }) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    let cur = 0;
    const step = Math.ceil(target / 40);
    const t = setInterval(() => {
      cur = Math.min(cur + step, target);
      setVal(cur);
      if (cur >= target) clearInterval(t);
    }, 20);
    return () => clearInterval(t);
  }, [target]);
  return <>{val}</>;
}

export function NewSearch() {
  const [product, setProduct] = useState('');
  const [country, setCountry] = useState('');
  const [count, setCount] = useState('10');
  const [lang, setLang] = useState('');
  const [running, setRunning] = useState(false);
  const [steps, setSteps] = useState<StepStatus[]>(['idle', 'idle', 'idle', 'idle', 'idle']);
  const [progress, setProgress] = useState(0);
  const [stepMsg, setStepMsg] = useState('');
  const [results, setResults] = useState<ResultRow[]>([]);
  const [done, setDone] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout>[]>([]);

  const mockResults: ResultRow[] = [
    { company: 'Euro Trade GmbH', contact: 'Hans Mueller', email: 'h.mueller@eurotrade.de', country: country || 'ألمانيا 🇩🇪', score: 92, ready: false },
    { company: 'Paris Import SARL', contact: 'Claire Dupont', email: 'claire@parisimport.fr', country: country || 'فرنسا 🇫🇷', score: 88, ready: false },
    { company: 'Amsterdam Goods BV', contact: 'Jan de Vries', email: 'j.devries@amstgoods.nl', country: country || 'هولندا 🇳🇱', score: 85, ready: false },
    { company: 'Mediterranean Corp', contact: 'Sofia Rossi', email: 'sofia@medcorp.it', country: country || 'إيطاليا 🇮🇹', score: 79, ready: false },
    { company: 'Nordic Supply AB', contact: 'Erik Larsson', email: 'e.larsson@nordic.se', country: country || 'السويد 🇸🇪', score: 75, ready: false },
  ];

  const handleStart = () => {
    if (!product.trim()) {
      toast.error('يرجى إدخال المنتج أو القطاع');
      return;
    }
    setRunning(true);
    setDone(false);
    setResults([]);
    setSteps(['idle', 'idle', 'idle', 'idle', 'idle']);
    setProgress(0);
    timerRef.current.forEach(clearTimeout);

    const schedule = (fn: () => void, delay: number) => {
      const t = setTimeout(fn, delay);
      timerRef.current.push(t);
    };

    // Step 1
    schedule(() => {
      setSteps(['running', 'idle', 'idle', 'idle', 'idle']);
      setStepMsg('إرسال الطلب إلى Hermes AI...');
      setProgress(5);
    }, 200);

    schedule(() => {
      setSteps(['done', 'idle', 'idle', 'idle', 'idle']);
      setProgress(20);
    }, 1400);

    // Step 2
    schedule(() => {
      setSteps(['done', 'running', 'idle', 'idle', 'idle']);
      setStepMsg(`مسح المصادر الدولية للمستوردين في ${country || 'أوروبا'}...`);
    }, 1600);

    [1, 2, 3, 4, 5].forEach((n, idx) => {
      schedule(() => {
        setStepMsg(`وجد ${n} شركة...`);
        setProgress(20 + idx * 5);
        setResults(prev => {
          const row = { ...mockResults[idx], ready: false };
          if (prev.find(r => r.company === row.company)) return prev;
          return [...prev, row];
        });
      }, 1800 + idx * 600);
    });

    schedule(() => {
      setSteps(['done', 'done', 'idle', 'idle', 'idle']);
      setProgress(50);
    }, 4800);

    // Step 3
    schedule(() => {
      setSteps(['done', 'done', 'running', 'idle', 'idle']);
      setStepMsg('تحليل المنافسين الصينيين والآسيويين...');
    }, 5000);

    schedule(() => {
      setSteps(['done', 'done', 'done', 'idle', 'idle']);
      setProgress(68);
    }, 7000);

    // Step 4
    schedule(() => {
      setSteps(['done', 'done', 'done', 'running', 'idle']);
      setStepMsg(`توليد رسائل التواصل باللغة ${lang || 'الإنجليزية'}...`);
    }, 7200);

    schedule(() => {
      setSteps(['done', 'done', 'done', 'done', 'idle']);
      setProgress(85);
      setResults(prev => prev.map(r => ({ ...r, ready: true })));
    }, 9500);

    // Step 5
    schedule(() => {
      setSteps(['done', 'done', 'done', 'done', 'running']);
      setStepMsg('حفظ البيانات في قاعدة البيانات...');
    }, 9700);

    schedule(() => {
      setSteps(['done', 'done', 'done', 'done', 'done']);
      setProgress(100);
      setStepMsg('اكتملت العملية بنجاح!');
      setRunning(false);
      setDone(true);
      toast.success('تم اكتشاف المستوردين وتوليد الرسائل بنجاح');
    }, 11500);
  };

  const canStart = product.trim().length > 0;

  return (
    <div style={{ fontFamily: FONTS.arabic, direction: 'rtl', maxWidth: 900, margin: '0 auto' }}>
      {/* Hero */}
      <div style={{
        textAlign: 'center',
        marginBottom: 32,
        padding: '32px 0 0',
        position: 'relative',
      }}>
        <div style={{
          position: 'absolute', top: 0, right: '50%', transform: 'translateX(50%)',
          width: 500, height: 200,
          background: 'radial-gradient(ellipse, rgba(200,168,75,0.06) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />
        <h1 style={{
          fontFamily: FONTS.display,
          fontSize: '3rem',
          fontWeight: 900,
          color: C.textPrimary,
          margin: '0 0 8px',
          lineHeight: 1.2,
        }}>
          صيادٌ للصفقات <span style={{ color: C.gold }}>العالمية</span>
        </h1>
        <p style={{
          fontSize: 15,
          color: C.textSec,
          lineHeight: 1.7,
          maxWidth: 600,
          margin: '0 auto 24px',
        }}>
          منظومة استخبارات تصديرية تحلل المنافسين وتصطاد المستوردين
          وتصوغ رسائل تواصل احترافية بلغة الجمهور المستهدف
        </p>

        {/* Animated Stats */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: 40 }}>
          {[
            { val: 127, label: 'مستورد' },
            { val: 98, label: 'رسالة' },
            { val: 6, label: 'منافس' },
          ].map((s) => (
            <div key={s.label} style={{ textAlign: 'center' }}>
              <div style={{ fontFamily: FONTS.mono, fontSize: '1.5rem', color: C.gold, fontWeight: 500 }}>
                <AnimatedCounter target={s.val} />
              </div>
              <div style={{ fontSize: 11, color: C.textMuted, marginTop: 2 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Search Form Card */}
      <div style={{
        background: C.bgCard,
        border: `1px solid ${C.border}`,
        borderTop: `2px solid transparent`,
        backgroundImage: `linear-gradient(${C.bgCard}, ${C.bgCard}), linear-gradient(90deg, transparent, ${C.gold}, transparent)`,
        backgroundOrigin: 'border-box',
        backgroundClip: 'padding-box, border-box',
        borderRadius: 16,
        padding: 32,
        position: 'relative',
        overflow: 'hidden',
        marginBottom: 20,
      }}>
        <div style={{
          position: 'absolute', top: 0, right: 0, width: 160, height: 160,
          background: 'radial-gradient(circle, rgba(200,168,75,0.07) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />

        <div style={{
          fontSize: 11,
          color: C.gold,
          textTransform: 'uppercase',
          letterSpacing: '0.12em',
          marginBottom: 20,
        }}>▸ بحث جديد</div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
          <Field
            label="المنتج أو القطاع"
            value={product}
            onChange={setProduct}
            placeholder="مثال: سجاد، زيت أرغان، منتجات غذائية..."
          />
          <SelectField
            label="الدولة المستهدفة"
            value={country}
            onChange={setCountry}
            options={countries}
            placeholder="اختر الدولة..."
          />
          <Field
            label="عدد النتائج"
            value={count}
            onChange={setCount}
            placeholder="10"
            type="number"
          />
          <SelectField
            label="لغة الرسائل"
            value={lang}
            onChange={setLang}
            options={languages}
            placeholder="اختر اللغة..."
          />
        </div>

        <button
          onClick={handleStart}
          disabled={!canStart || running}
          style={{
            width: '100%',
            height: 52,
            background: canStart && !running ? C.gold : '#4a3e2a',
            color: '#0a0d12',
            border: 'none',
            borderRadius: 8,
            fontSize: 15,
            fontWeight: 600,
            cursor: canStart && !running ? 'pointer' : 'not-allowed',
            fontFamily: FONTS.arabic,
            transition: 'all 0.2s ease',
            opacity: canStart && !running ? 1 : 0.5,
          }}
          onMouseEnter={(e) => {
            if (canStart && !running) {
              (e.target as HTMLButtonElement).style.background = C.goldBright;
              (e.target as HTMLButtonElement).style.transform = 'scale(1.01)';
            }
          }}
          onMouseLeave={(e) => {
            (e.target as HTMLButtonElement).style.background = canStart && !running ? C.gold : '#4a3e2a';
            (e.target as HTMLButtonElement).style.transform = 'scale(1)';
          }}
        >
          {running ? '⏳ جارٍ التنفيذ...' : '▸ ابدأ الاستخبارات التصديرية'}
        </button>
      </div>

      {/* Progress Section */}
      {(running || done) && (
        <div style={{
          background: C.bgCard,
          border: `1px solid ${C.border}`,
          borderRadius: 12,
          padding: 20,
          marginBottom: 20,
          animation: 'slideDown 0.3s ease',
        }}>
          {/* Progress bar header */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <span style={{ fontSize: 13, color: C.textPrimary }}>{stepMsg}</span>
            <span style={{ fontFamily: FONTS.mono, color: C.gold, fontSize: 13 }}>{progress}%</span>
          </div>

          {/* Progress bar */}
          <div style={{
            width: '100%',
            height: 4,
            background: '#1c2330',
            borderRadius: 2,
            marginBottom: 16,
            overflow: 'hidden',
          }}>
            <div style={{
              height: '100%',
              width: `${progress}%`,
              background: `linear-gradient(90deg, ${C.gold}, ${C.goldBright})`,
              borderRadius: 2,
              transition: 'width 0.4s ease',
            }} />
          </div>

          {/* Steps */}
          {STEPS.map((s, i) => {
            const status = steps[i];
            return (
              <div key={s.id} style={{
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                padding: '8px 12px',
                borderRadius: 8,
                marginBottom: 4,
                background: status === 'running'
                  ? 'rgba(200,168,75,0.08)'
                  : status === 'done'
                    ? 'rgba(45,212,160,0.05)'
                    : 'transparent',
                transition: 'background 0.3s',
              }}>
                <span style={{ fontSize: 14, flexShrink: 0 }}>
                  {status === 'done' ? '✅' : status === 'running'
                    ? <span style={{ display: 'inline-block', animation: 'spin 1s linear infinite', color: C.gold }}>⏳</span>
                    : '⬜'
                  }
                </span>
                <span style={{
                  fontSize: 13,
                  color: status === 'running' ? C.gold : status === 'done' ? C.success : C.textMuted,
                  fontFamily: FONTS.arabic,
                  transition: 'color 0.3s',
                }}>{s.label}</span>
              </div>
            );
          })}
        </div>
      )}

      {/* Results Table */}
      {results.length > 0 && (
        <div style={{
          background: C.bgCard,
          border: `1px solid ${C.border}`,
          borderRadius: 16,
          overflow: 'hidden',
        }}>
          <div style={{ padding: '16px 20px', borderBottom: `1px solid ${C.border}` }}>
            <span style={{ fontSize: 15, color: C.textPrimary, fontWeight: 600 }}>
              نتائج البحث
              <span style={{
                marginRight: 8,
                background: 'rgba(200,168,75,0.15)',
                color: C.gold,
                fontSize: 11,
                padding: '2px 8px',
                borderRadius: 10,
                fontFamily: FONTS.mono,
              }}>{results.length}</span>
            </span>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 80px 80px', padding: '10px 20px', background: 'rgba(255,255,255,0.02)', borderBottom: `1px solid ${C.border}` }}>
            {['الشركة', 'جهة التواصل', 'الدولة', 'التقييم', 'الرسالة'].map(h => (
              <div key={h} style={{ fontSize: 11, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.08em' }}>{h}</div>
            ))}
          </div>

          {results.map((r, i) => (
            <div
              key={r.company}
              style={{
                display: 'grid',
                gridTemplateColumns: '2fr 1fr 1fr 80px 80px',
                padding: '14px 20px',
                borderBottom: i < results.length - 1 ? `1px solid rgba(255,255,255,0.05)` : 'none',
                opacity: r.ready ? 1 : 0.6,
                animation: `slideIn 0.3s ease ${i * 0.1}s both`,
                transition: 'opacity 0.4s',
              }}
            >
              <div>
                <div style={{ fontSize: 13, color: C.textPrimary, fontWeight: 500 }}>{r.company}</div>
                <div style={{ fontSize: 11, color: C.textMuted, marginTop: 2 }}>{r.email}</div>
              </div>
              <div style={{ fontSize: 13, color: C.textSec, display: 'flex', alignItems: 'center' }}>{r.contact}</div>
              <div style={{ fontSize: 13, color: C.textSec, display: 'flex', alignItems: 'center' }}>{r.country}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <div style={{ flex: 1, height: 4, background: '#1c2330', borderRadius: 2 }}>
                  <div style={{
                    width: `${r.score}%`,
                    height: '100%',
                    background: r.score >= 85 ? C.success : r.score >= 70 ? C.gold : C.danger,
                    borderRadius: 2,
                  }} />
                </div>
                <span style={{ fontSize: 10, color: C.textMuted, fontFamily: FONTS.mono, flexShrink: 0 }}>{r.score}</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                {r.ready ? (
                  <span style={{
                    background: 'rgba(45,212,160,0.12)',
                    color: C.success,
                    fontSize: 10,
                    padding: '3px 8px',
                    borderRadius: 10,
                  }}>جاهزة ✓</span>
                ) : (
                  <span style={{ color: C.textMuted, fontSize: 11, animation: 'pulse 1.5s infinite' }}>⏳</span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <style>{`
        @keyframes slideDown {
          from { opacity: 0; transform: translateY(-10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes slideIn {
          from { opacity: 0; transform: translateX(10px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
      `}</style>
    </div>
  );
}

function Field({ label, value, onChange, placeholder, type = 'text' }: {
  label: string; value: string; onChange: (v: string) => void;
  placeholder: string; type?: string;
}) {
  const [focused, setFocused] = useState(false);
  return (
    <div>
      <div style={{ fontSize: 11, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6 }}>
        {label}
      </div>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={{
          width: '100%',
          background: C.bgInput,
          border: `1px solid ${focused ? C.gold : C.border}`,
          borderRadius: 8,
          padding: '12px 16px',
          fontSize: 14,
          color: C.textPrimary,
          fontFamily: FONTS.arabic,
          outline: 'none',
          boxSizing: 'border-box',
          boxShadow: focused ? `0 0 0 3px rgba(200,168,75,0.1)` : 'none',
          transition: 'all 0.15s',
        }}
      />
    </div>
  );
}

function SelectField({ label, value, onChange, options, placeholder }: {
  label: string; value: string; onChange: (v: string) => void;
  options: string[]; placeholder: string;
}) {
  const [focused, setFocused] = useState(false);
  return (
    <div>
      <div style={{ fontSize: 11, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6 }}>
        {label}
      </div>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={{
          width: '100%',
          background: C.bgInput,
          border: `1px solid ${focused ? C.gold : C.border}`,
          borderRadius: 8,
          padding: '12px 16px',
          fontSize: 14,
          color: value ? C.textPrimary : C.textMuted,
          fontFamily: FONTS.arabic,
          outline: 'none',
          boxSizing: 'border-box',
          boxShadow: focused ? `0 0 0 3px rgba(200,168,75,0.1)` : 'none',
          transition: 'all 0.15s',
          cursor: 'pointer',
          appearance: 'none',
        }}
      >
        <option value="" style={{ background: C.bgCard, color: C.textMuted }}>{placeholder}</option>
        {options.map(o => (
          <option key={o} value={o} style={{ background: C.bgCard, color: C.textPrimary }}>{o}</option>
        ))}
      </select>
    </div>
  );
}
