import React, { useState, useRef } from 'react';
import { toast } from 'sonner';
import { Upload, FileText } from 'lucide-react';
import { C, FONTS } from './colors';

export function PDFAnalysis() {
  const [dragging, setDragging] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [product, setProduct] = useState('');
  const [market, setMarket] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [results, setResults] = useState<null | {
    quality: number; pricing: string; strengths: string[]; gaps: string[];
  }>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const [focused1, setFocused1] = useState(false);
  const [focused2, setFocused2] = useState(false);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const f = e.dataTransfer.files[0];
    if (f && f.type === 'application/pdf') {
      setFile(f);
      toast.success(`تم رفع الملف: ${f.name}`);
    } else {
      toast.error('يرجى رفع ملف PDF فقط');
    }
  };

  const handleAnalyze = () => {
    if (!file) { toast.error('يرجى رفع ملف PDF أولاً'); return; }
    setAnalyzing(true);
    setTimeout(() => {
      setAnalyzing(false);
      setResults({
        quality: 78,
        pricing: 'تنافسي مع هامش تحسين 15-20%',
        strengths: ['جودة المواد موثقة بشهادات دولية', 'تنوع التصاميم يلبي طلب السوق الأوروبية', 'أسلوب العرض احترافي'],
        gaps: ['غياب معلومات الشحن والتسليم', 'لا يوجد شهادة CE أو ISO مذكورة', 'الأسعار غير مدرجة في الكتالوج'],
      });
      toast.success('اكتمل تحليل الكتالوج بنجاح');
    }, 3000);
  };

  return (
    <div style={{ fontFamily: FONTS.arabic, direction: 'rtl', maxWidth: 740, margin: '0 auto' }}>
      {/* Pro banner */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        padding: '10px 16px',
        background: 'rgba(168,85,247,0.08)',
        border: '1px solid rgba(168,85,247,0.25)',
        borderRadius: 8,
        marginBottom: 20,
        fontSize: 12,
        color: '#c084fc',
      }}>
        <span>👑</span>
        <span>هذه الميزة متاحة في خطة <strong>Pro</strong> — أنت مشترك حالياً في Pro</span>
      </div>

      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 22, fontWeight: 600, color: C.textPrimary, margin: '0 0 6px' }}>
          تحليل الكتالوج ومقارنته بالسوق العالمي
        </h1>
        <p style={{ fontSize: 13, color: C.textSec, margin: 0 }}>
          ارفع كتالوجك أو ملف PDF الخاص بك وسنحلله بالذكاء الاصطناعي
        </p>
      </div>

      {/* Drop zone */}
      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
        onClick={() => inputRef.current?.click()}
        style={{
          border: `2px dashed ${dragging ? C.gold : C.borderGold}`,
          borderRadius: 12,
          padding: '48px 24px',
          textAlign: 'center',
          background: dragging ? 'rgba(200,168,75,0.06)' : 'rgba(200,168,75,0.03)',
          cursor: 'pointer',
          marginBottom: 20,
          transition: 'all 0.2s',
        }}
      >
        <input
          ref={inputRef}
          type="file"
          accept=".pdf"
          style={{ display: 'none' }}
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) { setFile(f); toast.success(`تم اختيار: ${f.name}`); }
          }}
        />
        {file ? (
          <div>
            <FileText size={36} color={C.gold} style={{ margin: '0 auto 10px', display: 'block' }} />
            <div style={{ fontSize: 14, color: C.textPrimary, marginBottom: 4 }}>{file.name}</div>
            <div style={{ fontSize: 12, color: C.textMuted }}>{(file.size / 1024 / 1024).toFixed(2)} MB</div>
          </div>
        ) : (
          <div>
            <Upload size={36} color={dragging ? C.gold : 'rgba(200,168,75,0.4)'} style={{ margin: '0 auto 12px', display: 'block' }} />
            <div style={{ fontSize: 14, color: C.textSec, marginBottom: 6 }}>اسحب وأسقط ملف PDF هنا</div>
            <div style={{ fontSize: 12, color: C.textMuted }}>أو انقر للاختيار من جهازك</div>
          </div>
        )}
      </div>

      {/* Form fields */}
      <div style={{
        background: C.bgCard,
        border: `1px solid ${C.border}`,
        borderTop: `2px solid ${C.gold}`,
        borderRadius: 16,
        padding: 24,
        marginBottom: 20,
      }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
          <div>
            <div style={{ fontSize: 11, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6 }}>المنتج أو القطاع</div>
            <input
              value={product}
              onChange={(e) => setProduct(e.target.value)}
              placeholder="مثال: سجاد يدوي..."
              onFocus={() => setFocused1(true)}
              onBlur={() => setFocused1(false)}
              style={{
                width: '100%',
                background: C.bgInput,
                border: `1px solid ${focused1 ? C.gold : C.border}`,
                borderRadius: 8,
                padding: '12px 16px',
                fontSize: 14,
                color: C.textPrimary,
                fontFamily: FONTS.arabic,
                outline: 'none',
                boxSizing: 'border-box',
                boxShadow: focused1 ? `0 0 0 3px rgba(200,168,75,0.1)` : 'none',
                transition: 'all 0.15s',
              }}
            />
          </div>
          <div>
            <div style={{ fontSize: 11, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6 }}>السوق المستهدف للمقارنة</div>
            <input
              value={market}
              onChange={(e) => setMarket(e.target.value)}
              placeholder="مثال: أوروبا الغربية..."
              onFocus={() => setFocused2(true)}
              onBlur={() => setFocused2(false)}
              style={{
                width: '100%',
                background: C.bgInput,
                border: `1px solid ${focused2 ? C.gold : C.border}`,
                borderRadius: 8,
                padding: '12px 16px',
                fontSize: 14,
                color: C.textPrimary,
                fontFamily: FONTS.arabic,
                outline: 'none',
                boxSizing: 'border-box',
                boxShadow: focused2 ? `0 0 0 3px rgba(200,168,75,0.1)` : 'none',
                transition: 'all 0.15s',
              }}
            />
          </div>
        </div>

        <button
          onClick={handleAnalyze}
          disabled={analyzing}
          style={{
            width: '100%',
            height: 48,
            background: analyzing ? '#2a2210' : C.gold,
            color: '#0a0d12',
            border: 'none',
            borderRadius: 8,
            fontSize: 14,
            fontWeight: 600,
            cursor: analyzing ? 'not-allowed' : 'pointer',
            fontFamily: FONTS.arabic,
            transition: 'all 0.2s',
          }}
        >{analyzing ? '⏳ جارٍ التحليل...' : '▸ تحليل الكتالوج بالذكاء الاصطناعي'}</button>
      </div>

      {/* Results */}
      {results && (
        <div style={{
          background: C.bgCard,
          border: `1px solid ${C.border}`,
          borderRadius: 16,
          padding: 24,
          animation: 'slideDown 0.3s ease',
        }}>
          <div style={{ fontSize: 15, fontWeight: 600, color: C.textPrimary, marginBottom: 20 }}>نتائج التحليل</div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
            <div style={{ background: '#0a0d12', borderRadius: 12, padding: 16 }}>
              <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 8 }}>جودة الكتالوج</div>
              <div style={{ fontSize: '1.8rem', fontFamily: FONTS.mono, color: results.quality >= 80 ? C.success : C.gold }}>
                {results.quality}%
              </div>
              <div style={{ height: 4, background: '#1c2330', borderRadius: 2, marginTop: 8 }}>
                <div style={{
                  width: `${results.quality}%`,
                  height: '100%',
                  background: results.quality >= 80 ? C.success : C.gold,
                  borderRadius: 2,
                }} />
              </div>
            </div>
            <div style={{ background: '#0a0d12', borderRadius: 12, padding: 16 }}>
              <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 8 }}>تحليل التسعير</div>
              <div style={{ fontSize: 13, color: C.textPrimary, lineHeight: 1.5 }}>{results.pricing}</div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div>
              <div style={{ fontSize: 12, color: C.success, marginBottom: 8, fontWeight: 600 }}>✅ نقاط القوة</div>
              {results.strengths.map((s, i) => (
                <div key={i} style={{ fontSize: 12, color: C.textSec, marginBottom: 6, display: 'flex', gap: 6 }}>
                  <span style={{ color: C.success, flexShrink: 0 }}>▸</span>
                  <span>{s}</span>
                </div>
              ))}
            </div>
            <div>
              <div style={{ fontSize: 12, color: C.danger, marginBottom: 8, fontWeight: 600 }}>⚠️ نقاط يجب تحسينها</div>
              {results.gaps.map((g, i) => (
                <div key={i} style={{ fontSize: 12, color: C.textSec, marginBottom: 6, display: 'flex', gap: 6 }}>
                  <span style={{ color: C.danger, flexShrink: 0 }}>▸</span>
                  <span>{g}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes slideDown {
          from { opacity: 0; transform: translateY(-8px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
