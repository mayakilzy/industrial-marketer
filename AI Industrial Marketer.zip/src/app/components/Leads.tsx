import React, { useState } from 'react';
import { toast } from 'sonner';
import { C, FONTS } from './colors';

interface Lead {
  id: number;
  company: string;
  contact: string;
  flag: string;
  country: string;
  city: string;
  product: string;
  score: number;
  status: '🔥 حار' | '🟡 دافئ' | '❄️ بارد';
  email: string;
  phone: string;
  message: string;
}

const leads: Lead[] = [
  {
    id: 1, company: 'Euro Trade GmbH', contact: 'Hans Mueller',
    flag: '🇩🇪', country: 'ألمانيا', city: 'هامبورغ',
    product: 'سجاد تركي', score: 92, status: '🔥 حار',
    email: 'h.mueller@eurotrade.de', phone: '+49 40 123456',
    message: 'Dear Hans, we would like to offer our premium Turkish carpets...',
  },
  {
    id: 2, company: 'Paris Import SARL', contact: 'Claire Dupont',
    flag: '🇫🇷', country: 'فرنسا', city: 'باريس',
    product: 'زيت أرغان', score: 88, status: '🔥 حار',
    email: 'claire@parisimport.fr', phone: '+33 1 2345678',
    message: 'Chère Claire, nous souhaitons vous présenter notre huile d\'argan...',
  },
  {
    id: 3, company: 'Amsterdam Goods BV', contact: 'Jan de Vries',
    flag: '🇳🇱', country: 'هولندا', city: 'أمستردام',
    product: 'توابل', score: 83, status: '🟡 دافئ',
    email: 'j.devries@amstgoods.nl', phone: '+31 20 1234567',
    message: 'Beste Jan, wij willen onze premium kruiden presenteren...',
  },
  {
    id: 4, company: 'Mediterranean Corp', contact: 'Sofia Rossi',
    flag: '🇮🇹', country: 'إيطاليا', city: 'ميلانو',
    product: 'منتجات غذائية', score: 74, status: '🟡 دافئ',
    email: 'sofia@medcorp.it', phone: '+39 02 1234567',
    message: 'Cara Sofia, vorremmo presentarvi i nostri prodotti alimentari...',
  },
  {
    id: 5, company: 'Nordic Supply AB', contact: 'Erik Larsson',
    flag: '🇸🇪', country: 'السويد', city: 'ستوكهولم',
    product: 'منسوجات', score: 65, status: '❄️ بارد',
    email: 'e.larsson@nordic.se', phone: '+46 8 1234567',
    message: 'Dear Erik, we are pleased to introduce our textile products...',
  },
  {
    id: 6, company: 'Madrid Trade SL', contact: 'Carlos Garcia',
    flag: '🇪🇸', country: 'إسبانيا', city: 'مدريد',
    product: 'خلاط حمص', score: 78, status: '🟡 دافئ',
    email: 'c.garcia@madridtrade.es', phone: '+34 91 1234567',
    message: 'Estimado Carlos, nos complace presentarle nuestros productos...',
  },
  {
    id: 7, company: 'London Imports Ltd', contact: 'James Smith',
    flag: '🇬🇧', country: 'بريطانيا', city: 'لندن',
    product: 'منتجات بلاستيك', score: 55, status: '❄️ بارد',
    email: 'j.smith@londonimports.co.uk', phone: '+44 20 1234567',
    message: 'Dear James, we would like to offer our plastic products...',
  },
];

function StatusBadge({ status }: { status: Lead['status'] }) {
  const map: Record<string, { bg: string; color: string }> = {
    '🔥 حار': { bg: 'rgba(45,212,160,0.12)', color: C.success },
    '🟡 دافئ': { bg: 'rgba(200,168,75,0.12)', color: C.gold },
    '❄️ بارد': { bg: 'rgba(226,85,85,0.12)', color: C.danger },
  };
  const s = map[status];
  return (
    <span style={{
      background: s.bg,
      color: s.color,
      fontSize: 11,
      padding: '3px 9px',
      borderRadius: 20,
      whiteSpace: 'nowrap',
    }}>{status}</span>
  );
}

function ScoreBar({ score }: { score: number }) {
  const color = score >= 85 ? C.success : score >= 70 ? C.gold : C.danger;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      <div style={{ width: 60, height: 4, background: '#1c2330', borderRadius: 2 }}>
        <div style={{ width: `${score}%`, height: '100%', background: color, borderRadius: 2 }} />
      </div>
      <span style={{ fontSize: 10, fontFamily: FONTS.mono, color: C.textMuted }}>{score}</span>
    </div>
  );
}

interface LeadModalProps {
  lead: Lead;
  onClose: () => void;
}

function LeadModal({ lead, onClose }: LeadModalProps) {
  return (
    <div
      style={{
        position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        zIndex: 200, animation: 'fadeIn 0.2s ease',
      }}
      onClick={onClose}
    >
      <div
        style={{
          background: C.bgCard,
          border: `1px solid ${C.borderMed}`,
          borderTop: `2px solid ${C.gold}`,
          borderRadius: 16,
          width: 580,
          maxWidth: '90vw',
          maxHeight: '85vh',
          overflowY: 'auto',
          animation: 'slideUp 0.25s ease',
          fontFamily: FONTS.arabic,
          direction: 'rtl',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          padding: '20px 24px',
          borderBottom: `1px solid ${C.border}`,
        }}>
          <div>
            <div style={{ fontSize: 16, fontWeight: 600, color: C.textPrimary }}>{lead.company}</div>
            <div style={{ fontSize: 12, color: C.textMuted, marginTop: 2 }}>{lead.contact}</div>
          </div>
          <button
            onClick={onClose}
            style={{
              background: 'none', border: `1px solid ${C.border}`,
              borderRadius: 8, width: 32, height: 32,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', color: C.textSec, fontSize: 16,
            }}
          >×</button>
        </div>

        <div style={{ padding: '20px 24px' }}>
          {/* Fields */}
          {[
            { label: 'الدولة', value: `${lead.flag} ${lead.country} — ${lead.city}` },
            { label: 'المنتج', value: lead.product },
            { label: 'البريد الإلكتروني', value: lead.email },
            { label: 'الهاتف', value: lead.phone },
          ].map(({ label, value }) => (
            <div key={label} style={{
              display: 'flex',
              gap: 16,
              marginBottom: 14,
              alignItems: 'flex-start',
            }}>
              <div style={{ fontSize: 12, color: C.textMuted, minWidth: 120, flexShrink: 0, paddingTop: 1 }}>{label}:</div>
              <div style={{ fontSize: 13, color: C.textPrimary }}>{value}</div>
            </div>
          ))}

          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 12, color: C.textMuted, marginBottom: 6 }}>التقييم:</div>
            <ScoreBar score={lead.score} />
          </div>

          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 12, color: C.textMuted, marginBottom: 6 }}>الحالة:</div>
            <StatusBadge status={lead.status} />
          </div>

          <div style={{ height: 1, background: C.border, margin: '16px 0' }} />

          {/* Buttons */}
          <div style={{ display: 'flex', gap: 10 }}>
            <button
              onClick={() => { toast.success('تم عرض الرسالة'); }}
              style={{
                flex: 1, height: 40,
                background: 'rgba(200,168,75,0.1)',
                border: `1px solid ${C.gold}`,
                color: C.gold,
                borderRadius: 8,
                fontSize: 13,
                cursor: 'pointer',
                fontFamily: FONTS.arabic,
              }}
            >عرض الرسالة</button>
            <button
              onClick={() => {
                navigator.clipboard.writeText(`${lead.email}\n${lead.phone}`);
                toast.success('تم نسخ بيانات التواصل');
              }}
              style={{
                flex: 1, height: 40,
                background: 'rgba(255,255,255,0.04)',
                border: `1px solid ${C.border}`,
                color: C.textSec,
                borderRadius: 8,
                fontSize: 13,
                cursor: 'pointer',
                fontFamily: FONTS.arabic,
              }}
            >نسخ بيانات التواصل</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function Leads() {
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [hoveredRow, setHoveredRow] = useState<number | null>(null);

  return (
    <div style={{ fontFamily: FONTS.arabic, direction: 'rtl' }}>
      {/* Toolbar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <h1 style={{ fontSize: 22, fontWeight: 600, color: C.textPrimary, margin: 0 }}>المستوردون المكتشفون</h1>
          <span style={{
            background: 'rgba(200,168,75,0.15)',
            color: C.gold,
            fontSize: 12,
            padding: '2px 10px',
            borderRadius: 10,
            fontFamily: FONTS.mono,
          }}>{leads.length}</span>
        </div>

        <div style={{ display: 'flex', gap: 8 }}>
          {['↓ تصدير CSV', '↻ تحديث', '⊕ فلتر'].map((btn) => (
            <button
              key={btn}
              onClick={() => toast.success(`${btn} — قيد التطوير`)}
              style={{
                padding: '7px 14px',
                background: 'none',
                border: `1px solid rgba(255,255,255,0.12)`,
                borderRadius: 8,
                color: C.textSec,
                fontSize: 12,
                cursor: 'pointer',
                fontFamily: FONTS.arabic,
                transition: 'all 0.15s',
              }}
              onMouseEnter={(e) => {
                (e.target as HTMLElement).style.borderColor = C.gold;
                (e.target as HTMLElement).style.color = C.gold;
              }}
              onMouseLeave={(e) => {
                (e.target as HTMLElement).style.borderColor = 'rgba(255,255,255,0.12)';
                (e.target as HTMLElement).style.color = C.textSec;
              }}
            >{btn}</button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div style={{
        background: C.bgCard,
        border: `1px solid ${C.border}`,
        borderRadius: 16,
        overflow: 'hidden',
      }}>
        {/* Header */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: '40px 2.5fr 1.3fr 1.2fr 110px 100px 80px',
          padding: '10px 20px',
          background: 'rgba(255,255,255,0.02)',
          borderBottom: `1px solid ${C.border}`,
        }}>
          {['#', 'الاسم والشركة', 'الدولة', 'المنتج', 'التقييم', 'الحالة', 'الإجراء'].map((h) => (
            <div key={h} style={{
              fontSize: 11, color: C.textMuted,
              textTransform: 'uppercase', letterSpacing: '0.08em',
            }}>{h}</div>
          ))}
        </div>

        {leads.map((lead, i) => (
          <div
            key={lead.id}
            style={{
              display: 'grid',
              gridTemplateColumns: '40px 2.5fr 1.3fr 1.2fr 110px 100px 80px',
              padding: '0 20px',
              height: 64,
              alignItems: 'center',
              borderBottom: i < leads.length - 1 ? `1px solid rgba(255,255,255,0.05)` : 'none',
              background: hoveredRow === i ? 'rgba(255,255,255,0.02)' : 'transparent',
              transition: 'background 0.15s',
              cursor: 'default',
            }}
            onMouseEnter={() => setHoveredRow(i)}
            onMouseLeave={() => setHoveredRow(null)}
          >
            <div style={{ fontSize: 11, color: C.textMuted, fontFamily: FONTS.mono }}>
              {String(lead.id).padStart(2, '0')}
            </div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 500, color: C.textPrimary }}>{lead.company}</div>
              <div style={{ fontSize: 12, color: C.textMuted }}>{lead.contact}</div>
            </div>
            <div>
              <span style={{
                background: 'rgba(91,156,246,0.12)',
                color: C.info,
                fontSize: 11,
                padding: '3px 8px',
                borderRadius: 20,
              }}>
                {lead.flag} {lead.country} · {lead.city}
              </span>
            </div>
            <div style={{ fontSize: 13, color: C.textSec }}>{lead.product}</div>
            <div><ScoreBar score={lead.score} /></div>
            <div><StatusBadge status={lead.status} /></div>
            <div>
              <button
                onClick={() => setSelectedLead(lead)}
                style={{
                  padding: '5px 12px',
                  background: 'none',
                  border: `1px solid rgba(255,255,255,0.12)`,
                  borderRadius: 6,
                  color: C.textSec,
                  fontSize: 12,
                  cursor: 'pointer',
                  fontFamily: FONTS.arabic,
                  transition: 'all 0.15s',
                }}
                onMouseEnter={(e) => {
                  const t = e.currentTarget;
                  t.style.borderColor = C.gold;
                  t.style.color = C.gold;
                  t.style.background = 'rgba(200,168,75,0.06)';
                }}
                onMouseLeave={(e) => {
                  const t = e.currentTarget;
                  t.style.borderColor = 'rgba(255,255,255,0.12)';
                  t.style.color = C.textSec;
                  t.style.background = 'none';
                }}
              >عرض</button>
            </div>
          </div>
        ))}
      </div>

      {selectedLead && (
        <LeadModal lead={selectedLead} onClose={() => setSelectedLead(null)} />
      )}

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
