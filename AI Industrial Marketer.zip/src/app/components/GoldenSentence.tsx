import React, { useState } from 'react';
import { toast } from 'sonner';
import { C, FONTS } from './colors';

const sentences = [
  {
    lang: 'DE', langName: 'الألمانية', flag: '🇩🇪',
    text: `"Wir bieten nicht nur Produkte — wir bieten Ihnen einen zuverlässigen Partner, der Ihre Qualitätsstandards kennt und Ihre Lieferkette stärkt."`,
    translation: 'نحن لا نقدم منتجات فحسب — بل نقدم لكم شريكاً موثوقاً يعرف معايير الجودة لديكم ويعزز سلسلة التوريد الخاصة بكم.',
    context: 'مناسبة لـ: مستوردو الألمانيا، السويد، النمسا',
  },
  {
    lang: 'FR', langName: 'الفرنسية', flag: '🇫🇷',
    text: `"Notre engagement dépasse la simple transaction commerciale — nous construisons avec vous une relation durable fondée sur la confiance et l'excellence."`,
    translation: 'التزامنا يتجاوز مجرد الصفقة التجارية — نبني معكم علاقة دائمة مبنية على الثقة والتميز.',
    context: 'مناسبة لـ: مستوردو فرنسا، بلجيكا، كندا الفرنكوفونية',
  },
  {
    lang: 'EN', langName: 'الإنجليزية', flag: '🇬🇧',
    text: `"Your success in the market is our mission — we bring you products that don't just sell, but build your brand's reputation."`,
    translation: 'نجاحكم في السوق هو مهمتنا — نقدم لكم منتجات لا تُباع فحسب، بل تبني سمعة علامتكم التجارية.',
    context: 'مناسبة لـ: مستوردو بريطانيا، أمريكا، أستراليا',
  },
];

export function GoldenSentence() {
  const [selected, setSelected] = useState(0);
  const s = sentences[selected];

  return (
    <div style={{ fontFamily: FONTS.arabic, direction: 'rtl', maxWidth: 780, margin: '0 auto' }}>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 22, fontWeight: 600, color: C.textPrimary, margin: '0 0 6px' }}>
          ⭐ الجملة الذهبية
        </h1>
        <p style={{ fontSize: 13, color: C.textSec, margin: 0 }}>
          الجملة الأقوى تأثيراً لفتح باب التواصل مع المستوردين
        </p>
      </div>

      {/* Language tabs */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        {sentences.map((s, i) => (
          <button
            key={s.lang}
            onClick={() => setSelected(i)}
            style={{
              padding: '7px 16px',
              background: selected === i ? 'rgba(200,168,75,0.12)' : 'none',
              border: `1px solid ${selected === i ? C.gold : C.border}`,
              borderRadius: 8,
              color: selected === i ? C.gold : C.textSec,
              fontSize: 12,
              cursor: 'pointer',
              fontFamily: FONTS.arabic,
              transition: 'all 0.15s',
            }}
          >{s.flag} {s.langName}</button>
        ))}
      </div>

      {/* Main card */}
      <div style={{
        background: C.bgCard,
        border: `1px solid ${C.borderGold}`,
        borderRadius: 16,
        padding: 36,
        position: 'relative',
        overflow: 'hidden',
        marginBottom: 16,
      }}>
        {/* Gold glow */}
        <div style={{
          position: 'absolute', top: -40, right: -40, width: 250, height: 250,
          background: 'radial-gradient(circle, rgba(200,168,75,0.06) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />
        <div style={{
          position: 'absolute', bottom: -40, left: -40, width: 200, height: 200,
          background: 'radial-gradient(circle, rgba(200,168,75,0.04) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />

        {/* Star */}
        <div style={{
          fontSize: '2rem',
          marginBottom: 8,
          filter: `drop-shadow(0 0 8px ${C.gold})`,
        }}>★</div>

        {/* Label */}
        <div style={{
          fontSize: 11,
          color: C.gold,
          textTransform: 'uppercase',
          letterSpacing: '0.12em',
          marginBottom: 20,
        }}>الجملة الذهبية — {s.langName} {s.flag}</div>

        {/* Main text */}
        <div style={{
          fontSize: 17,
          color: C.textPrimary,
          lineHeight: 1.75,
          fontStyle: 'italic',
          direction: 'ltr',
          textAlign: 'left',
          marginBottom: 20,
          padding: '16px 20px',
          borderRight: `3px solid ${C.gold}`,
          background: 'rgba(200,168,75,0.04)',
          borderRadius: '0 4px 4px 0',
        }}>{s.text}</div>

        {/* Translation */}
        <div style={{
          fontSize: 14,
          color: C.textSec,
          lineHeight: 1.7,
          marginBottom: 8,
        }}>{s.translation}</div>

        <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 24 }}>
          📍 {s.context}
        </div>

        {/* CTA button */}
        <button
          onClick={() => {
            navigator.clipboard.writeText(s.text);
            toast.success('تم نسخ الجملة الذهبية للحافظة');
          }}
          style={{
            width: '100%',
            height: 44,
            background: `linear-gradient(135deg, rgba(200,168,75,0.2), rgba(232,201,106,0.1))`,
            border: `1px solid ${C.gold}`,
            borderRadius: 8,
            color: C.gold,
            fontSize: 14,
            fontWeight: 600,
            cursor: 'pointer',
            fontFamily: FONTS.arabic,
            transition: 'all 0.2s',
          }}
          onMouseEnter={(e) => {
            (e.currentTarget).style.background = `rgba(200,168,75,0.2)`;
          }}
          onMouseLeave={(e) => {
            (e.currentTarget).style.background = `linear-gradient(135deg, rgba(200,168,75,0.2), rgba(232,201,106,0.1))`;
          }}
        >نسخ للاستخدام في الرسائل ★</button>
      </div>

      {/* Tips */}
      <div style={{
        background: C.bgCard,
        border: `1px solid ${C.border}`,
        borderRadius: 12,
        padding: 20,
      }}>
        <div style={{ fontSize: 12, color: C.textMuted, marginBottom: 12 }}>💡 نصائح الاستخدام</div>
        {[
          'استخدم الجملة في مقدمة الرسالة مباشرة بعد التحية',
          'خصّص اسم الشركة قبل إرسالها',
          'يمكنك دمجها مع تفاصيل المنتج في الفقرة التالية',
        ].map((tip, i) => (
          <div key={i} style={{
            display: 'flex',
            gap: 8,
            marginBottom: 8,
            fontSize: 12,
            color: C.textSec,
            alignItems: 'flex-start',
          }}>
            <span style={{ color: C.gold, flexShrink: 0 }}>▸</span>
            <span>{tip}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
