import React, { useState } from 'react';
import { Bell, Search } from 'lucide-react';
import { C, FONTS } from './colors';

type Page = 'dashboard' | 'new-search' | 'leads' | 'messages' | 'competitors' | 'golden' | 'pdf' | 'api-keys' | 'settings';

const pageNames: Record<Page, string> = {
  'dashboard': 'لوحة التحكم',
  'new-search': 'بحث جديد',
  'leads': 'المستوردون',
  'messages': 'الرسائل',
  'competitors': 'تحليل المنافسين',
  'golden': 'الجملة الذهبية',
  'pdf': 'تحليل PDF',
  'api-keys': 'مفاتيح API',
  'settings': 'الإعدادات',
};

interface TopbarProps {
  currentPage: Page;
}

export function Topbar({ currentPage }: TopbarProps) {
  const [searchVal, setSearchVal] = useState('');

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 260,
      height: 56,
      background: 'rgba(10,13,18,0.92)',
      backdropFilter: 'blur(16px)',
      borderBottom: `1px solid ${C.border}`,
      display: 'flex',
      alignItems: 'center',
      padding: '0 24px',
      gap: 16,
      zIndex: 90,
      fontFamily: FONTS.arabic,
    }}>
      {/* Right: page name (in RTL this is the start) */}
      <div style={{ fontSize: 15, fontWeight: 500, color: C.textPrimary, whiteSpace: 'nowrap', minWidth: 120 }}>
        {pageNames[currentPage]}
      </div>

      {/* Center: search bar */}
      <div style={{ flex: 1, maxWidth: 380, margin: '0 auto', position: 'relative' }}>
        <Search
          size={14}
          style={{
            position: 'absolute',
            top: '50%',
            right: 12,
            transform: 'translateY(-50%)',
            color: C.textMuted,
            pointerEvents: 'none',
          }}
        />
        <input
          type="text"
          value={searchVal}
          onChange={(e) => setSearchVal(e.target.value)}
          placeholder="بحث عن مستورد أو عملية سابقة..."
          style={{
            width: '100%',
            background: C.bgInput,
            border: `1px solid ${C.border}`,
            borderRadius: 8,
            padding: '7px 36px 7px 12px',
            fontSize: 13,
            color: C.textPrimary,
            fontFamily: FONTS.arabic,
            outline: 'none',
            boxSizing: 'border-box',
          }}
          onFocus={(e) => {
            e.target.style.borderColor = C.gold;
            e.target.style.boxShadow = `0 0 0 2px rgba(200,168,75,0.12)`;
          }}
          onBlur={(e) => {
            e.target.style.borderColor = C.border;
            e.target.style.boxShadow = 'none';
          }}
        />
      </div>

      {/* Left: notifications + Hermes + avatar */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginLeft: 'auto' }}>
        {/* Hermes status */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: 6,
          padding: '4px 10px',
          background: 'rgba(45,212,160,0.08)',
          border: `1px solid rgba(45,212,160,0.2)`,
          borderRadius: 20,
          fontSize: 11,
          color: C.success,
          fontFamily: FONTS.arabic,
          whiteSpace: 'nowrap',
        }}>
          <span style={{ width: 6, height: 6, background: C.success, borderRadius: '50%', animation: 'pulse 2s infinite', display: 'inline-block' }} />
          Hermes نشط
        </div>

        {/* Bell */}
        <div style={{ position: 'relative', cursor: 'pointer' }}>
          <Bell size={18} color={C.textSec} />
          <span style={{
            position: 'absolute',
            top: -4,
            left: -4,
            width: 14,
            height: 14,
            background: C.danger,
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: 8,
            color: '#fff',
            fontFamily: FONTS.mono,
            border: `1px solid ${C.bgMain}`,
          }}>3</span>
        </div>

        {/* Avatar */}
        <div style={{
          width: 32,
          height: 32,
          borderRadius: '50%',
          background: 'linear-gradient(135deg, #c8a84b, #0f1318)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: 13,
          color: C.gold,
          border: `1px solid ${C.border}`,
          cursor: 'pointer',
        }}>ع</div>
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
      `}</style>
    </div>
  );
}
