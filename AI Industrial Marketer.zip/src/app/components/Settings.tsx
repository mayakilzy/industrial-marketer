import React, { useState } from 'react';
import { toast } from 'sonner';
import { C, FONTS } from './colors';

type Tab = 'profile' | 'server' | 'appearance' | 'notifications' | 'plan';

const tabLabels: { id: Tab; label: string }[] = [
  { id: 'profile', label: 'الملف الشخصي' },
  { id: 'server', label: 'إعدادات الخادم' },
  { id: 'appearance', label: 'المظهر' },
  { id: 'notifications', label: 'التنبيهات' },
  { id: 'plan', label: 'خطتي' },
];

function ServerStatus({ label, port, active }: { label: string; port: string; active: boolean }) {
  return (
    <div style={{
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '10px 0',
      borderBottom: `1px solid rgba(255,255,255,0.05)`,
    }}>
      <span style={{ fontSize: 13, color: C.textSec, fontFamily: FONTS.arabic }}>{label}</span>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{
          width: 7, height: 7, borderRadius: '50%',
          background: active ? C.success : C.danger,
          display: 'inline-block',
          animation: active ? 'pulse 2s infinite' : 'none',
        }} />
        <span style={{ fontSize: 12, color: active ? C.success : C.danger, fontFamily: FONTS.mono }}>
          {active ? `نشط على ${port}` : 'متوقف'}
        </span>
      </div>
    </div>
  );
}

function ProfileTab() {
  const [name, setName] = useState('عبدالرحمن الأحمد');
  const [email, setEmail] = useState('admin@industrial.ai');
  const [company, setCompany] = useState('Industrial AI Export');
  const [focused, setFocused] = useState('');

  const fieldStyle = (id: string) => ({
    width: '100%',
    background: C.bgInput,
    border: `1px solid ${focused === id ? C.gold : C.border}`,
    borderRadius: 8,
    padding: '11px 16px',
    fontSize: 14,
    color: C.textPrimary,
    fontFamily: FONTS.arabic,
    outline: 'none',
    boxSizing: 'border-box' as const,
    boxShadow: focused === id ? `0 0 0 3px rgba(200,168,75,0.1)` : 'none',
    transition: 'all 0.15s',
  });

  return (
    <div style={{ maxWidth: 500 }}>
      {[
        { id: 'name', label: 'الاسم الكامل', value: name, set: setName },
        { id: 'email', label: 'البريد الإلكتروني', value: email, set: setEmail },
        { id: 'company', label: 'اسم الشركة / المنصة', value: company, set: setCompany },
      ].map(({ id, label, value, set }) => (
        <div key={id} style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 11, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6 }}>
            {label}
          </div>
          <input
            value={value}
            onChange={(e) => set(e.target.value)}
            onFocus={() => setFocused(id)}
            onBlur={() => setFocused('')}
            style={fieldStyle(id)}
          />
        </div>
      ))}
      <button
        onClick={() => toast.success('تم حفظ الملف الشخصي')}
        style={{
          marginTop: 8,
          padding: '10px 24px',
          background: C.gold,
          border: 'none',
          borderRadius: 8,
          color: '#0a0d12',
          fontSize: 13,
          fontWeight: 600,
          cursor: 'pointer',
          fontFamily: FONTS.arabic,
        }}
      >حفظ التغييرات</button>
    </div>
  );
}

function ServerTab() {
  return (
    <div>
      <div style={{
        background: C.bgCard,
        border: `1px solid ${C.border}`,
        borderRadius: 12,
        padding: 20,
        marginBottom: 16,
      }}>
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 4 }}>عنوان IP</div>
          <div style={{ fontSize: 14, color: C.textPrimary, fontFamily: FONTS.mono }}>167.86.76.18</div>
        </div>
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 4 }}>نظام التشغيل</div>
          <div style={{ fontSize: 13, color: C.textPrimary }}>Ubuntu 24.04 LTS</div>
        </div>
        <div>
          <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 4 }}>حالة الاتصال</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ width: 7, height: 7, borderRadius: '50%', background: C.success, display: 'inline-block', animation: 'pulse 2s infinite' }} />
            <span style={{ fontSize: 13, color: C.success }}>متصل</span>
            <span style={{ fontSize: 11, color: C.textMuted }}>— آخر فحص: منذ دقيقة</span>
          </div>
        </div>
      </div>

      <div style={{
        background: C.bgCard,
        border: `1px solid ${C.border}`,
        borderRadius: 12,
        padding: 20,
      }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: C.textPrimary, marginBottom: 12 }}>حالة الخدمات</div>
        <ServerStatus label="Hermes AI" port="8642" active={true} />
        <ServerStatus label="NocoDB" port="8970" active={true} />
        <ServerStatus label="FastAPI" port="8900" active={true} />
      </div>

      <style>{`@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }`}</style>
    </div>
  );
}

function AppearanceTab() {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  return (
    <div>
      <div style={{ fontSize: 12, color: C.textMuted, marginBottom: 12 }}>المظهر</div>
      <div style={{
        display: 'inline-flex',
        background: '#0a0d12',
        border: `1px solid ${C.border}`,
        borderRadius: 8,
        padding: 3,
        gap: 3,
      }}>
        {[
          { id: 'dark' as const, label: '🌙 مظلم' },
          { id: 'light' as const, label: '☀️ مضيء' },
        ].map((opt) => (
          <button
            key={opt.id}
            onClick={() => setTheme(opt.id)}
            style={{
              padding: '8px 20px',
              background: theme === opt.id ? C.bgHover : 'transparent',
              border: `1px solid ${theme === opt.id ? C.gold : 'transparent'}`,
              borderRadius: 6,
              color: theme === opt.id ? C.textPrimary : C.textSec,
              fontSize: 13,
              cursor: 'pointer',
              fontFamily: FONTS.arabic,
              transition: 'all 0.15s',
            }}
          >{opt.label}</button>
        ))}
      </div>
      <div style={{ marginTop: 16, fontSize: 12, color: C.textMuted }}>
        {theme === 'dark' ? 'المظهر الداكن محدد حالياً' : 'المظهر المضيء — قيد التطوير'}
      </div>
    </div>
  );
}

function NotificationsTab() {
  const [settings, setSettings] = useState({
    newImporters: true,
    searchComplete: true,
    errors: true,
    weekly: false,
    tips: true,
  });

  const toggle = (key: keyof typeof settings) => {
    setSettings(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const notifItems = [
    { id: 'newImporters' as const, label: 'مستوردون جدد', desc: 'عند اكتشاف مستوردين جدد' },
    { id: 'searchComplete' as const, label: 'انتهاء البحث', desc: 'عند اكتمال عملية البحث' },
    { id: 'errors' as const, label: 'أخطاء الاتصال', desc: 'عند وجود خطأ في الاتصال بـ API' },
    { id: 'weekly' as const, label: 'ملخص أسبوعي', desc: 'تقرير أسبوعي بالأداء العام' },
    { id: 'tips' as const, label: 'نصائح وتحديثات', desc: 'نصائح لتحسين أداء البحث' },
  ];

  return (
    <div style={{ maxWidth: 500 }}>
      {notifItems.map((item) => (
        <div key={item.id} style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          padding: '14px 0',
          borderBottom: `1px solid rgba(255,255,255,0.05)`,
        }}>
          <div>
            <div style={{ fontSize: 14, color: C.textPrimary, marginBottom: 2 }}>{item.label}</div>
            <div style={{ fontSize: 11, color: C.textMuted }}>{item.desc}</div>
          </div>
          <div
            onClick={() => toggle(item.id)}
            style={{
              width: 40,
              height: 22,
              background: settings[item.id] ? C.gold : '#1c2330',
              border: `1px solid ${settings[item.id] ? C.gold : C.border}`,
              borderRadius: 11,
              cursor: 'pointer',
              position: 'relative',
              transition: 'all 0.2s',
            }}
          >
            <span style={{
              position: 'absolute',
              top: 2,
              right: settings[item.id] ? 2 : 'auto',
              left: settings[item.id] ? 'auto' : 2,
              width: 16,
              height: 16,
              background: settings[item.id] ? '#0a0d12' : '#555',
              borderRadius: '50%',
              transition: 'all 0.2s',
            }} />
          </div>
        </div>
      ))}
    </div>
  );
}

function PlanTab() {
  const plans = [
    {
      id: 'starter',
      name: 'Starter',
      price: '$29',
      period: '/شهر',
      border: 'rgba(255,255,255,0.12)',
      badge: null,
      features: ['10 عمليات بحث/شهر', '100 مستورد', 'رسائل بلغتين', 'تحليل 3 منافسين'],
      locked: ['تحليل PDF', 'Apollo.io', 'إرسال SMTP', 'بحث غير محدود'],
      current: false,
    },
    {
      id: 'pro',
      name: 'Pro',
      price: '$79',
      period: '/شهر',
      border: C.gold,
      badge: 'الأكثر شيوعاً',
      features: ['50 عملية بحث/شهر', '1000 مستورد', 'رسائل بـ 6 لغات', 'تحليل 20 منافس', 'تحليل PDF', 'Apollo.io API'],
      locked: ['بحث غير محدود', 'فريق متعدد'],
      current: true,
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      price: 'مخصص',
      period: '',
      border: 'rgba(192,192,192,0.3)',
      badge: null,
      features: ['بحث غير محدود', 'مستوردون غير محدودون', 'جميع اللغات', 'تحليل كامل', 'دعم مخصص', 'فريق متعدد'],
      locked: [],
      current: false,
    },
  ];

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16 }}>
      {plans.map((plan) => (
        <div key={plan.id} style={{
          background: C.bgCard,
          border: `1px solid ${plan.border}`,
          borderRadius: 16,
          padding: 20,
          position: 'relative',
        }}>
          {plan.badge && (
            <div style={{
              position: 'absolute',
              top: -10,
              left: '50%',
              transform: 'translateX(-50%)',
              background: C.gold,
              color: '#0a0d12',
              fontSize: 10,
              padding: '2px 10px',
              borderRadius: 10,
              fontWeight: 600,
              whiteSpace: 'nowrap',
            }}>{plan.badge}</div>
          )}
          <div style={{ marginBottom: 12 }}>
            <div style={{ fontSize: 16, fontWeight: 600, color: C.textPrimary, marginBottom: 4 }}>{plan.name}</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
              <span style={{ fontFamily: FONTS.mono, fontSize: '1.5rem', color: plan.current ? C.gold : C.textPrimary }}>{plan.price}</span>
              <span style={{ fontSize: 12, color: C.textMuted }}>{plan.period}</span>
            </div>
          </div>

          {plan.features.map((f) => (
            <div key={f} style={{ display: 'flex', gap: 6, marginBottom: 6, fontSize: 12, color: C.textSec, alignItems: 'flex-start' }}>
              <span style={{ color: C.success, flexShrink: 0 }}>✓</span>
              <span>{f}</span>
            </div>
          ))}

          {plan.locked.map((f) => (
            <div key={f} style={{ display: 'flex', gap: 6, marginBottom: 6, fontSize: 12, color: C.textMuted, alignItems: 'center' }}>
              <span style={{ flexShrink: 0 }}>🔒</span>
              <span title="متاح في خطة أعلى">{f}</span>
            </div>
          ))}

          <button
            onClick={() => {
              if (plan.current) toast.info('أنت مشترك بهذه الخطة حالياً');
              else toast.success(`جارٍ الانتقال إلى ${plan.name}`);
            }}
            style={{
              width: '100%',
              marginTop: 16,
              padding: '9px 0',
              background: plan.current ? 'rgba(200,168,75,0.12)' : 'rgba(255,255,255,0.04)',
              border: `1px solid ${plan.current ? C.gold : C.border}`,
              borderRadius: 8,
              color: plan.current ? C.gold : C.textSec,
              fontSize: 12,
              cursor: 'pointer',
              fontFamily: FONTS.arabic,
            }}
          >{plan.current ? '✓ خطتك الحالية' : 'الترقية'}</button>
        </div>
      ))}
    </div>
  );
}

export function Settings() {
  const [tab, setTab] = useState<Tab>('profile');

  const renderTab = () => {
    switch (tab) {
      case 'profile': return <ProfileTab />;
      case 'server': return <ServerTab />;
      case 'appearance': return <AppearanceTab />;
      case 'notifications': return <NotificationsTab />;
      case 'plan': return <PlanTab />;
    }
  };

  return (
    <div style={{ fontFamily: FONTS.arabic, direction: 'rtl' }}>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 22, fontWeight: 600, color: C.textPrimary, margin: '0 0 6px' }}>الإعدادات</h1>
      </div>

      <div style={{ display: 'flex', gap: 24 }}>
        {/* Vertical tabs */}
        <div style={{ width: 180, flexShrink: 0 }}>
          {tabLabels.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              style={{
                width: '100%',
                display: 'block',
                padding: '10px 14px',
                background: tab === t.id ? 'rgba(200,168,75,0.08)' : 'none',
                border: 'none',
                borderRight: `3px solid ${tab === t.id ? C.gold : 'transparent'}`,
                borderRadius: '0 8px 8px 0',
                color: tab === t.id ? C.textPrimary : C.textSec,
                fontSize: 13,
                cursor: 'pointer',
                fontFamily: FONTS.arabic,
                textAlign: 'right',
                marginBottom: 2,
                transition: 'all 0.15s',
              }}
            >{t.label}</button>
          ))}
        </div>

        {/* Content */}
        <div style={{ flex: 1 }}>
          <div style={{
            background: C.bgCard,
            border: `1px solid ${C.border}`,
            borderRadius: 16,
            padding: 28,
          }}>
            {renderTab()}
          </div>
        </div>
      </div>
    </div>
  );
}
