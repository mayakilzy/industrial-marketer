import React, { useState } from 'react';
import { Eye, EyeOff, Lock } from 'lucide-react';
import { toast } from 'sonner';
import { C, FONTS } from './colors';

interface ApiKeyField {
  id: string;
  title: string;
  description: string;
  link: string;
  linkLabel: string;
  badge?: string;
  pro?: boolean;
  placeholder: string;
}

const apiFields: ApiKeyField[] = [
  {
    id: 'google_maps',
    title: 'Google Maps API Key',
    description: 'لجلب بيانات المستوردين الحقيقيين ومعلومات الشركات',
    link: 'https://console.cloud.google.com',
    linkLabel: 'احصل على مفتاح ↗',
    placeholder: 'AIza...',
  },
  {
    id: 'openrouter',
    title: 'OpenRouter API Key',
    description: 'لتشغيل نماذج الذكاء الاصطناعي (Hermes AI)',
    link: 'https://openrouter.ai',
    linkLabel: 'احصل على مفتاح ↗',
    placeholder: 'sk-or-...',
  },
  {
    id: 'apify',
    title: 'Apify API Key',
    description: 'لكشط بيانات B2B المتقدمة وتوسيع نطاق البحث',
    link: 'https://apify.com',
    linkLabel: 'احصل على مفتاح ↗',
    badge: 'يوسّع نطاق البحث 3×',
    placeholder: 'apify_api_...',
  },
  {
    id: 'apollo',
    title: 'Apollo.io API Key',
    description: 'للحصول على بيانات تواصل دقيقة وإيميلات احترافية',
    link: 'https://apollo.io',
    linkLabel: 'احصل على مفتاح ↗',
    pro: true,
    placeholder: 'your-apollo-key...',
  },
  {
    id: 'nocodb',
    title: 'NocoDB API Key',
    description: 'لحفظ البيانات في قاعدة بياناتك الخاصة والوصول إليها',
    link: 'https://nocodb.com',
    linkLabel: 'احصل على مفتاح ↗',
    placeholder: 'your-nocodb-token...',
  },
  {
    id: 'smtp',
    title: 'SMTP Settings',
    description: 'للإرسال المباشر للرسائل إلى المستوردين من المنصة',
    link: '#',
    linkLabel: 'كيفية الإعداد ↗',
    pro: true,
    placeholder: 'smtp://user:pass@host:587',
  },
];

interface KeyState {
  value: string;
  show: boolean;
  status: 'empty' | 'valid' | 'invalid';
}

function StatusDot({ status }: { status: KeyState['status'] }) {
  const color = status === 'valid' ? C.success : status === 'invalid' ? C.danger : '#444';
  return (
    <span style={{
      width: 7,
      height: 7,
      borderRadius: '50%',
      background: color,
      display: 'inline-block',
      animation: status === 'valid' ? 'pulse 2s infinite' : 'none',
    }} />
  );
}

export function APIKeys() {
  const [keys, setKeys] = useState<Record<string, KeyState>>(
    Object.fromEntries(apiFields.map(f => [f.id, { value: '', show: false, status: 'empty' as const }]))
  );
  const [hasChanges, setHasChanges] = useState(false);

  const update = (id: string, val: string) => {
    setHasChanges(true);
    setKeys(prev => ({
      ...prev,
      [id]: {
        ...prev[id],
        value: val,
        status: val.length === 0 ? 'empty' : val.length > 8 ? 'valid' : 'invalid',
      },
    }));
  };

  const toggleShow = (id: string) => {
    setKeys(prev => ({ ...prev, [id]: { ...prev[id], show: !prev[id].show } }));
  };

  return (
    <div style={{ fontFamily: FONTS.arabic, direction: 'rtl', maxWidth: 740, margin: '0 auto' }}>
      {/* Security banner */}
      <div style={{
        display: 'flex',
        alignItems: 'flex-start',
        gap: 12,
        padding: '14px 16px',
        background: 'rgba(91,156,246,0.08)',
        border: '1px solid rgba(91,156,246,0.2)',
        borderRadius: 8,
        marginBottom: 24,
        fontSize: 12,
        color: C.info,
      }}>
        <Lock size={16} style={{ flexShrink: 0, marginTop: 1 }} />
        <div>
          <div style={{ fontWeight: 600, marginBottom: 3 }}>🔒 تشفير آمن للمفاتيح</div>
          <div style={{ color: '#7aabf5', lineHeight: 1.5 }}>
            جميع المفاتيح مشفرة محلياً ولا تُرسل إلى أي خادم خارجي.
            تُستخدم فقط لإجراء طلبات API من متصفحك مباشرةً.
          </div>
        </div>
      </div>

      <div style={{ marginBottom: 20 }}>
        <h1 style={{ fontSize: 22, fontWeight: 600, color: C.textPrimary, margin: '0 0 6px' }}>مفاتيح API (BYOK)</h1>
        <p style={{ fontSize: 13, color: C.textSec, margin: 0 }}>أضف مفاتيحك الخاصة لتفعيل جميع مزايا المنصة</p>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {apiFields.map((field) => {
          const k = keys[field.id];
          return (
            <div key={field.id} style={{
              background: C.bgCard,
              border: `1px solid ${C.border}`,
              borderRadius: 12,
              padding: 20,
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                    <span style={{ fontSize: 14, fontWeight: 500, color: C.textPrimary, fontFamily: FONTS.mono }}>
                      {field.title}
                    </span>
                    {field.badge && (
                      <span style={{
                        background: 'rgba(45,212,160,0.12)',
                        color: C.success,
                        fontSize: 10,
                        padding: '2px 7px',
                        borderRadius: 10,
                        fontFamily: FONTS.arabic,
                      }}>{field.badge}</span>
                    )}
                    {field.pro && (
                      <span style={{
                        background: 'rgba(168,85,247,0.15)',
                        color: '#a855f7',
                        fontSize: 10,
                        padding: '2px 7px',
                        borderRadius: 10,
                        fontFamily: FONTS.arabic,
                      }}>Pro</span>
                    )}
                  </div>
                  <div style={{ fontSize: 12, color: C.textSec }}>{field.description}</div>
                </div>
                <a
                  href={field.link}
                  target="_blank"
                  rel="noreferrer"
                  style={{ fontSize: 11, color: C.gold, textDecoration: 'none', flexShrink: 0, marginRight: 12 }}
                >{field.linkLabel}</a>
              </div>

              <div style={{ position: 'relative' }}>
                <StatusDot status={k.status} />
                <input
                  type={k.show ? 'text' : 'password'}
                  value={k.value}
                  onChange={(e) => update(field.id, e.target.value)}
                  placeholder={field.placeholder}
                  style={{
                    width: '100%',
                    background: C.bgInput,
                    border: `1px solid ${C.border}`,
                    borderRadius: 8,
                    padding: '10px 40px 10px 40px',
                    fontSize: 13,
                    color: C.textPrimary,
                    fontFamily: FONTS.mono,
                    outline: 'none',
                    boxSizing: 'border-box',
                    direction: 'ltr',
                    textAlign: 'left',
                    marginTop: 8,
                    transition: 'border-color 0.15s',
                  }}
                  onFocus={(e) => { e.target.style.borderColor = C.gold; }}
                  onBlur={(e) => { e.target.style.borderColor = C.border; }}
                />
                <button
                  onClick={() => toggleShow(field.id)}
                  style={{
                    position: 'absolute',
                    left: 10,
                    bottom: 8,
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    color: C.textMuted,
                    display: 'flex',
                    alignItems: 'center',
                    padding: 4,
                  }}
                >
                  {k.show ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
                <span style={{
                  position: 'absolute',
                  right: 12,
                  bottom: 16,
                  width: 7,
                  height: 7,
                  borderRadius: '50%',
                  background: k.status === 'valid' ? C.success : k.status === 'invalid' ? C.danger : '#333',
                  display: 'inline-block',
                }} />
              </div>
            </div>
          );
        })}
      </div>

      {/* Save button */}
      <div style={{ marginTop: 20 }}>
        <button
          disabled={!hasChanges}
          onClick={() => {
            toast.success('تم حفظ المفاتيح وتفعيل الاتصال');
            setHasChanges(false);
          }}
          style={{
            width: '100%',
            height: 48,
            background: hasChanges ? C.gold : '#1c2330',
            color: hasChanges ? '#0a0d12' : C.textMuted,
            border: 'none',
            borderRadius: 8,
            fontSize: 14,
            fontWeight: 600,
            cursor: hasChanges ? 'pointer' : 'not-allowed',
            fontFamily: FONTS.arabic,
            transition: 'all 0.2s',
          }}
        >حفظ وتفعيل الاتصال 💾</button>
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
      `}</style>
    </div>
  );
}
